export const BACKTOP_DISTANCE = 1000

export const POP = 'pop';
export const NEW = 'new';
export const SELL = 'sell';
